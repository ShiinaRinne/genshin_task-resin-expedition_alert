from nonebot import on_command
from nonebot.rule import to_me
from nonebot.typing import T_State
from nonebot.adapters import Bot, Event

from .alert import qq_query
from .alert.getinfo.dataanalystic import *
from .alert.getinfo.receivedata import receive_data
from database import database

resin = on_command("resin", rule=to_me(), priority=5)


@resin.handle()
async def handle_first_receive(bot: Bot, event: Event, state: T_State):
    args = str(event.get_message()).strip()  # 首次发送命令时跟随的参数，例：/天气 上海，则args为上海
    if args:
        state["param"] = args  # 如果用户发送了参数则直接赋值


@resin.got("param", prompt="你想对我做些什么呢")
async def handle_param(bot: Bot, event: Event, state: T_State):
    Query_Param = state["param"]

    qq = event.get_user_id()
    db = database()
    basedata: BaseData = db.query_data(qq)[0]
    result: list[str] = receive_data(base_data)
    # query param
    await resin.finish('\n'.join(result))


async def get_all_info(bot: Bot, event: Event, state: T_State):
    db = database()
    results: list = db.query_data()
    for result in results:
        if(result.current_resin < result.max_resin): # and result.alert_sleep_time
            # 加一个时间 避免重复发送扰民
            pass
        else:
            qq = result.qq
            # send message to user
            pass


async def get_info(param: str):
    return alert.qqmessage()
