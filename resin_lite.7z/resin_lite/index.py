from alert import main
while True: 
    main()