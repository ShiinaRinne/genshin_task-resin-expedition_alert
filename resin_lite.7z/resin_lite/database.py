import pymysql
from .alert.getinfo.model import BaseData

class database():
    def __init__(self):
        self.db = pymysql.connect(host='localhost',
                                  user='root',
                                  password='',
                                  database='')
        self.cursor = self.db.cursor()

    def query(self,sql:str):
        self.cursor.execute(sql)
        results = self.cursor.fetchall()
        return results

    def query_data(self,qq:str=""):
        sql = f"select * from resin_bot"
        if(qq!=""):
            sql = f"select * from resin_bot where qq={qq}"

        data = self.query(sql)
        results:list = []
        for row in data:
            result:BaseData = BaseData.parse_obj(obj=row)
            results.append(result)
            