from .basedata import BaseData
from .configdata import ConfigData