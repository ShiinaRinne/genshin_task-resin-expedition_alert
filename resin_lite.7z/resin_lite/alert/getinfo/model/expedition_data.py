class Expedition_data:
    avatar_side_icon:str
    status:str
    remained_time:str