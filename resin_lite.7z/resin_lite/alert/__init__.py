from .getinfo import MysAPI, APIError
from .getinfo.model import BaseData
from .config import config
import time
import requests
import logging
import json

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')

log = logger = logging

def insert_data(data: BaseData) -> None:
    url = "https://api.youngmoe.com/alert/data"
    data = json.dumps(data)
    data["uid"] = config.UID
    requests.post(url=url, data=json.dumps(data))

def error_message(error_message: str) -> None:
    url = "https://api.youngmoe.com/alert/error"
    data: dict = {}
    data["uid"] = config.UID
    data["error_message"] = error_message
    requests.post(url=url, data=json.dumps(data))

def main() -> None:
    uid = config.UID
    cookie = config.COOKIE
    try:
        base_data: BaseData = MysAPI(uid, cookie).get_dailyNote()
        insert_data(base_data)
    except APIError:
        error_message(message="发生错误，请检查cookie与id是否对应或是否已开启米游社实时便笺功能。")
        exit()

    log.info(f'本轮运行结束，休眠{config.SLEEP_TIME}秒')
    time.sleep(config.SLEEP_TIME)